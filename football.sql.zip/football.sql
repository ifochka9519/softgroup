
CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_country` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `cities` (`id`, `name`, `id_country`) VALUES
(1, 'London', 2),
(2, 'Dnipro', 1),
(3, 'Barcelona', 3),
(4, 'Kyiv', 1),
(5, 'Manchester', 2);

CREATE TABLE `clubs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_city` int(11) NOT NULL,
  `id_league` int(11) NOT NULL,
  `year` year(4) NOT NULL,
  `id_president` int(11) NOT NULL,
  `id_stadium` int(11) NOT NULL,
  `revenue` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `clubs` (`id`, `name`, `id_city`, `id_league`, `year`, `id_president`, `id_stadium`, `revenue`) VALUES
(1, 'Dnipro', 2, 1, 1918, 1, 1, '1000000'),
(2, 'Manchester United', 5, 2, 1901, 5, 5, '300000000'),
(7, 'Chelsea', 1, 2, 1927, 6, 5, '30000000');

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `name`) VALUES
(1, 'Ukraine'),
(2, 'England'),
(3, 'Spain'),
(4, 'France'),
(5, 'Portugal');

CREATE TABLE `leagues` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_country` int(11) NOT NULL,
  `top_place` int(11) NOT NULL,
  `id_president` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `leagues` (`id`, `name`, `id_country`, `top_place`, `id_president`) VALUES
(1, 'Ukranian Premier League', 1, 10, 2),
(2, 'Premier League', 2, 1, 3),
(3, 'La Liga', 3, 2, 4);

CREATE TABLE `persone` (
  `id` int(11) NOT NULL,
  `first_name` text,
  `last_name` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `persone` (`id`, `first_name`, `last_name`) VALUES
(1, 'Igor', 'Kolomoyskyi'),
(2, 'Volodymyr', 'Heninson'),
(3, 'Marco', 'Silva'),
(4, 'Javier', 'Tebasa'),
(5, 'Avram', 'Glazer'),
(6, 'Roman', 'Abramovich');

CREATE TABLE `stadiums` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` year(4) NOT NULL,
  `capacity` int(11) NOT NULL,
  `id_city` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `stadiums` (`id`, `name`, `year`, `capacity`, `id_city`) VALUES
(1, 'Dnipro-Arena', 2008, 31003, 2),
(5, 'Stamford Bridge', 1901, 41490, 1),
(7, 'Camp Nou', 1927, 70050, 1);

CREATE TABLE `trophy` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `trophy` (`id`, `name`, `year`) VALUES
(1, 'Europa League Trophy', 1972),
(2, 'Champions League Trophy', 1956);

CREATE TABLE `victory` (
  `id` int(11) NOT NULL,
  `id_club` int(11) NOT NULL,
  `id_trophy` int(11) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `victory` (`id`, `id_club`, `id_trophy`, `year`) VALUES
(1, 1, 2, 1972),
(3, 1, 1, 1999),
(4, 7, 1, 1995);


ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `clubs`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `leagues`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `persone`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `stadiums`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `trophy`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `victory`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
ALTER TABLE `clubs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
ALTER TABLE `leagues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
ALTER TABLE `persone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
ALTER TABLE `stadiums`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
ALTER TABLE `trophy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
ALTER TABLE `victory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
